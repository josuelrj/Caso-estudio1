import os, sqlite3, json, re, secrets
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, g, abort
from werkzeug.security import generate_password_hash, check_password_hash

ROOT = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("SGH_DB", os.path.join(ROOT, "sg_business_hub.db"))
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "CAMBIAR-ESTA-CLAVE-ANTES-DE-PRODUCCION-" + secrets.token_hex(16))
app.permanent_session_lifetime = timedelta(minutes=30)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024

ROLES = ["ADMINISTRADOR", "SERVICIO AL CLIENTE", "DISEÑADOR", "FABRICANTE", "SERVICIOS PROFESIONALES"]
MODULES = {
 "dashboard": ("Tablero de control", ["ADMINISTRADOR","SERVICIO AL CLIENTE"]),
 "clients": ("Clientes", ["ADMINISTRADOR","SERVICIO AL CLIENTE"]),
 "projects": ("Proyectos y tareas", ["ADMINISTRADOR","SERVICIO AL CLIENTE","DISEÑADOR"]),
 "tasks": ("Tareas", ["ADMINISTRADOR","SERVICIO AL CLIENTE","DISEÑADOR","FABRICANTE"]),
 "requests": ("Solicitudes", ["ADMINISTRADOR","SERVICIO AL CLIENTE"]),
 "quotes": ("Cotizaciones", ["ADMINISTRADOR","SERVICIO AL CLIENTE"]),
 "visuals": ("Visualizaciones", ["ADMINISTRADOR","DISEÑADOR"]),
 "production": ("Producción y entregas", ["ADMINISTRADOR","SERVICIO AL CLIENTE","FABRICANTE"]),
 "communications": ("Comunicaciones", ["ADMINISTRADOR","SERVICIO AL CLIENTE"]),
 "inventory": ("Materiales e inventario", ["ADMINISTRADOR","FABRICANTE"]),
 "users": ("Usuarios y seguridad", ["ADMINISTRADOR"]),
 "reports": ("Reportes", ["ADMINISTRADOR","SERVICIO AL CLIENTE"]),
 "ai": ("Inteligencia artificial", ["ADMINISTRADOR"]),
 "audit": ("Bitácora", ["ADMINISTRADOR"])
}
FIELDS = {
 "clients":[("name","Nombre",1),("type","Tipo de cliente",1),("identification","Identificación",0),("phone","Teléfono (8 dígitos)",1),("email","Correo",0),("address","Dirección",0)],
 "projects":[("name","Nombre del proyecto",1),("client","Cliente",1),("service_type","Tipo de servicio",1),("status","Estado",1),("start_date","Fecha de inicio",0),("due_date","Fecha de entrega",0),("description","Descripción",0)],
 "requests":[("client","Cliente",1),("channel","Canal",1),("service_type","Tipo de servicio",1),("description","Descripción",1),("status","Estado",0)],
 "quotes":[("client","Cliente",1),("project","Proyecto",0),("amount","Monto antes de IVA (₡)",1),("status","Estado",1),("expiry_date","Fecha de vencimiento",0),("rejection_reason","Motivo de rechazo",0)],
 "visuals":[("project","Proyecto",1),("file_name","Nombre del archivo",1),("description","Descripción",0),("status","Estado",0)],
 "production":[("project","Proyecto",1),("order_number","Orden de producción",1),("specifications","Especificaciones",1),("status","Estado",1),("due_date","Fecha límite",0)],
 "communications":[("client","Cliente",1),("channel","Canal",1),("summary","Resumen",1),("date","Fecha y hora",0)],
 "inventory":[("code","Código",1),("name","Material",1),("unit","Unidad de medida",1),("stock","Existencia",1),("minimum","Stock mínimo",1)],
 "users":[("name","Nombre",1),("email","Correo",1),("role","Rol",1)],
 "tasks":[("project","Proyecto",1),("stage","Etapa",1),("name","Tarea",1),("assignee","Responsable",0),("priority","Prioridad",1),("status","Estado",1),("due_date","Fecha límite",0),("progress","Avance (%)",0)]
}
NAV = ["dashboard","clients","projects","tasks","requests","quotes","visuals","production","communications","inventory","users","reports","ai","audit"]

def connect():
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,role TEXT NOT NULL,password_hash TEXT NOT NULL,active INTEGER DEFAULT 1,failed INTEGER DEFAULT 0,locked_until TEXT,created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY AUTOINCREMENT,module TEXT NOT NULL,data TEXT NOT NULL,status TEXT DEFAULT 'Activo',created_by INTEGER,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,user_id INTEGER,user_email TEXT,role TEXT,module TEXT,operation TEXT,record_id INTEGER,old_value TEXT,new_value TEXT);
        """)
        if not db.execute("SELECT id FROM users LIMIT 1").fetchone():
            db.execute("INSERT INTO users(name,email,role,password_hash,created_at) VALUES(?,?,?,?,?)",
                       ("Administrador inicial","admin@sgbusiness.local","ADMINISTRADOR",generate_password_hash("Admin12345!"),datetime.now().isoformat(timespec="seconds")))

def audit(module, operation, record_id=None, old=None, new=None):
    db=connect()
    db.execute("INSERT INTO audit(at,user_id,user_email,role,module,operation,record_id,old_value,new_value) VALUES(?,?,?,?,?,?,?,?,?)",
       (datetime.now().isoformat(timespec="seconds"),session.get("uid"),session.get("email"),session.get("role"),module,operation,record_id,json.dumps(old,ensure_ascii=False) if old else None,json.dumps(new,ensure_ascii=False) if new else None))
    db.commit(); db.close()

def allowed(module):
    return session.get("role") in MODULES.get(module,("",[]))[1]

def require_login(fn):
    @wraps(fn)
    def wrapper(*a,**kw):
        if not session.get("uid"): return redirect(url_for("login"))
        if not session.permanent: session.permanent=True
        if session.get("last_seen"):
            try:
                if datetime.now()-datetime.fromisoformat(session["last_seen"]) > timedelta(minutes=30):
                    session.clear(); flash("La sesión expiró por inactividad. Inicie sesión nuevamente.","warning"); return redirect(url_for("login"))
            except ValueError: session.clear(); return redirect(url_for("login"))
        session["last_seen"]=datetime.now().isoformat()
        return fn(*a,**kw)
    return wrapper

def module_access(key):
    if key not in MODULES: abort(404)
    if not allowed(key):
        audit(key,"ACCESO_DENEGADO")
        flash("No tiene permisos para realizar esta acción","danger")
        return False
    return True

@app.before_request
def setup(): init_db()

@app.template_filter("fromjson")
def fromjson_filter(value):
    try: return json.loads(value or "{}")
    except (ValueError, TypeError): return {}

@app.context_processor
def context():
    return {"nav":NAV,"modules":MODULES,"current_role":session.get("role"),"current_user":session.get("name"),"roles":ROLES}

@app.route("/")
def home(): return redirect(url_for("dashboard") if session.get("uid") else url_for("login"))

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        email=request.form.get("email","").strip().lower()
        password=request.form.get("password","")
        db=connect(); u=db.execute("SELECT * FROM users WHERE lower(email)=?",(email,)).fetchone()
        if not u or not u["active"]:
            flash("Correo o contraseña incorrectos","danger")
        elif u["locked_until"] and datetime.fromisoformat(u["locked_until"])>datetime.now():
            flash("La cuenta está bloqueada temporalmente. Intente más tarde.","danger")
        elif not check_password_hash(u["password_hash"],password):
            fails=u["failed"]+1; locked=(datetime.now()+timedelta(minutes=15)).isoformat() if fails>=5 else None
            db.execute("UPDATE users SET failed=?,locked_until=? WHERE id=?",(fails,locked,u["id"])); db.commit()
            flash("Correo o contraseña incorrectos","danger")
        else:
            db.execute("UPDATE users SET failed=0,locked_until=NULL WHERE id=?",(u["id"],)); db.commit()
            session.clear(); session.permanent=True
            session.update(uid=u["id"],email=u["email"],name=u["name"],role=u["role"],last_seen=datetime.now().isoformat())
            audit("seguridad","INICIO_SESION")
            return redirect(url_for("dashboard"))
        db.close()
    return render_template("login.html")

@app.route("/logout")
def logout():
    if session.get("uid"): audit("seguridad","CIERRE_SESION")
    session.clear(); return redirect(url_for("login"))

@app.route("/dashboard")
@require_login
def dashboard():
    if not module_access("dashboard"): return redirect(url_for("home"))
    db=connect()
    counts={}
    for key in ["projects","requests","quotes","clients","inventory","production"]:
        counts[key]=db.execute("SELECT count(*) n FROM records WHERE module=?",(key,)).fetchone()["n"]
    projects=[json.loads(r["data"]) for r in db.execute("SELECT data FROM records WHERE module='projects'")]
    statuses=collections_counter(p.get("status","Sin estado") for p in projects)
    recent=db.execute("SELECT * FROM records ORDER BY id DESC LIMIT 6").fetchall()
    db.close()
    return render_template("dashboard.html",counts=counts,statuses=statuses,recent=recent,json=json)

def collections_counter(vals):
    out={}
    for v in vals: out[v]=out.get(v,0)+1
    return out

@app.route("/<key>",methods=["GET","POST"])
@require_login
def listing(key):
    if key not in FIELDS: abort(404)
    if not module_access(key): return redirect(url_for("home"))
    fields=FIELDS[key]
    if request.method=="POST":
        data={k:request.form.get(k,"").strip() for k,_,_ in fields}
        missing=[label for k,label,req in fields if req and not data.get(k)]
        if missing:
            flash("Complete los campos obligatorios: "+", ".join(missing),"danger")
        elif key=="clients":
            if data.get("email") and not re.match(r"^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$",data["email"]):
                flash("Formato de correo inválido","danger")
            elif data.get("phone") and not re.fullmatch(r"\\d{8}",data["phone"]):
                flash("El teléfono debe tener 8 dígitos","danger")
            elif data.get("identification") and duplicate("clients","identification",data["identification"]):
                flash("Ya existe un cliente con esta identificación","danger")
            else: save_record(key,data)
        elif key=="inventory":
            if not data["stock"].replace(".","",1).isdigit() or float(data["stock"])<0 or float(data["minimum"])<0:
                flash("Las existencias y el stock mínimo no pueden ser negativos","danger")
            elif duplicate("inventory","code",data["code"]): flash("Ya existe un material con ese código","danger")
            else: save_record(key,data)
        elif key=="users":
            if not re.match(r"^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$",data["email"]): flash("Formato de correo inválido","danger")
            elif data["role"] not in ROLES: flash("Seleccione un rol válido","danger")
            else:
                db=connect()
                try:
                    db.execute("INSERT INTO users(name,email,role,password_hash,created_at) VALUES(?,?,?,?,?)",
                        (data["name"],data["email"].lower(),data["role"],generate_password_hash("Temporal123!"),datetime.now().isoformat(timespec="seconds")))
                    db.commit(); audit("users","CREAR_USUARIO"); flash("Usuario registrado. Contraseña temporal: Temporal123! Cambiarla al ingresar.","success")
                except sqlite3.IntegrityError: flash("Ya existe un usuario con ese correo","danger")
                db.close()
        else: save_record(key,data)
    db=connect()
    rows=db.execute("SELECT * FROM records WHERE module=? ORDER BY id DESC",(key,)).fetchall()
    if key=="users": rows=db.execute("SELECT id,name,email,role,active,created_at FROM users ORDER BY id DESC").fetchall()
    db.close()
    return render_template("listing.html",key=key,title=MODULES[key][0],fields=fields,rows=rows)

def duplicate(module,field,value):
    db=connect()
    for r in db.execute("SELECT data FROM records WHERE module=?",(module,)):
        if json.loads(r["data"]).get(field,"").lower()==value.lower(): db.close(); return True
    db.close(); return False

def save_record(key,data):
    db=connect(); now=datetime.now().isoformat(timespec="seconds")
    cur=db.execute("INSERT INTO records(module,data,created_by,created_at,updated_at) VALUES(?,?,?,?,?)",
        (key,json.dumps(data,ensure_ascii=False),session["uid"],now,now))
    rid=cur.lastrowid; db.commit(); db.close()
    audit(key,"CREAR",rid,new=data); flash("Registro guardado correctamente","success")

@app.route("/delete/<int:rid>",methods=["POST"])
@require_login
def delete_record(rid):
    db=connect(); row=db.execute("SELECT * FROM records WHERE id=?",(rid,)).fetchone()
    if not row: db.close(); abort(404)
    key=row["module"]
    if not module_access(key): db.close(); return redirect(url_for("home"))
    old=json.loads(row["data"]); db.execute("DELETE FROM records WHERE id=?",(rid,)); db.commit(); db.close()
    audit(key,"ELIMINAR",rid,old=old); flash("Registro eliminado y movimiento auditado","success")
    return redirect(url_for("listing",key=key))

@app.route("/users/password",methods=["GET","POST"])
@require_login
def change_password():
    if request.method=="POST":
        p=request.form.get("password","")
        if len(p)<8 or not re.search(r"\\d",p): flash("La contraseña debe tener al menos 8 caracteres y un número","danger")
        else:
            db=connect(); db.execute("UPDATE users SET password_hash=? WHERE id=?",(generate_password_hash(p),session["uid"])); db.commit(); db.close()
            flash("Contraseña actualizada","success"); return redirect(url_for("dashboard"))
    return render_template("password.html")

@app.route("/reports")
@require_login
def reports():
    if not module_access("reports"): return redirect(url_for("home"))
    db=connect(); rows=db.execute("SELECT * FROM records ORDER BY module,id DESC").fetchall(); db.close()
    return render_template("reports.html",rows=rows)

@app.route("/ai")
@require_login
def ai():
    if not module_access("ai"): return redirect(url_for("home"))
    return render_template("ai.html")

@app.route("/audit")
@require_login
def audit_view():
    if not module_access("audit"): return redirect(url_for("home"))
    db=connect(); rows=db.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 200").fetchall(); db.close()
    return render_template("audit.html",rows=rows)

if __name__=="__main__":
    app.run(host="127.0.0.1",port=int(os.environ.get("PORT",5000)),debug=False)
