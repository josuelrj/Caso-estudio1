# SG Business Hub — Grupo 7

Aplicación web académica inicial basada en el archivo `AN02_Historias_de_Usuario_v4.xlsx`.

## Alcance de esta versión

Este repositorio contiene un **prototipo funcional inicial (MVP)**, no una implementación certificada de las 89 historias. Incluye:

- Inicio de sesión y contraseñas con hash seguro (Werkzeug).
- Roles: ADMINISTRADOR, SERVICIO AL CLIENTE, DISEÑADOR, FABRICANTE y SERVICIOS PROFESIONALES.
- Control de acceso por rol en las rutas principales.
- Bloqueo temporal después de cinco intentos fallidos.
- Cierre de sesión por inactividad de 30 minutos.
- Bitácora básica de auditoría para altas, bajas, inicio/cierre de sesión y accesos denegados.
- Formularios iniciales para clientes, proyectos, solicitudes, cotizaciones, visualizaciones, producción, comunicaciones, inventario, tareas y usuarios.
- Tablero inicial y vista de bitácora.
- Catálogo estructurado de las 89 historias y sus 576 escenarios en `docs_story_catalog.json`.
- Matriz de trazabilidad en `Matriz_Historias.csv`.

## Requisitos

- Python 3.10 o superior.
- pip.

## Ejecutar localmente

En Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
py app.py
```

En macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Abrir `http://127.0.0.1:5000`.

## Usuario inicial de demostración

- Correo: `admin@sgbusiness.local`
- Contraseña temporal: `Admin12345!`

Cambiar la contraseña inmediatamente desde el menú **Contraseña**. No reutilizar estas credenciales en un despliegue real.

## Base de datos

La aplicación crea automáticamente `sg_business_hub.db` (SQLite) al iniciar. El archivo está excluido de Git por `.gitignore`. Los datos de prueba son locales.

## Antes de publicar o desplegar

1. Definir una `SECRET_KEY` aleatoria mediante variable de entorno.
2. No publicar bases de datos ni datos personales reales.
3. Configurar HTTPS, copias de seguridad y política de retención.
4. Revisar controles de acceso y pruebas con cada rol.
5. Añadir migraciones y relaciones de base de datos normalizadas.
6. Implementar edición, búsquedas, filtros, adjuntos, exportaciones y validaciones específicas que faltan.
7. Implementar y validar modelos IA con datos históricos reales y anonimización.
8. Completar las historias de usuario y escenarios que aparecen como pendientes en `Matriz_Historias.csv`.

## Estado honesto de la implementación

La matriz inicia todas las historias como **Pendiente de validación**. Tener el catálogo y los formularios iniciales no significa que cada escenario esté implementado. No se deben entregar capturas como evidencia de funciones que no se hayan ejecutado y probado.

## Estructura

```text
SG-Business-Hub-Grupo7/
├── app.py
├── requirements.txt
├── Matriz_Historias.csv
├── docs_story_catalog.json
├── AN02_Historias_de_Usuario_v4.xlsx
└── app/
    ├── templates/
    └── static/
```
